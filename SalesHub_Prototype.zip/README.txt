SalesHub prototype

Open index.html in a web browser to test the prototype.

This is a front-end MVP/prototype. It includes:
- Dashboard
- Sales pipeline
- Leads
- Customers
- Quotes
- Orders
- Follow-up and new deal forms
- Responsive mobile layout

The next development stage would connect it to a real database, authentication, user accounts, email/WhatsApp notifications, and real quote/order workflows.
